
import type { Manifest, Evidence } from "./manifest.js";

export async function check(manifest: Manifest): Promise<{ passed: boolean; report: Evidence[] }> {
  const report: Evidence[] = [];
  return { passed: true, report };
}
