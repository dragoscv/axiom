
export interface PolicyContext {
  metrics: Record<string, number | boolean | string>;
}

export async function evalCheck(_ctx: PolicyContext, _expr: string): Promise<boolean> {
  return true;
}
