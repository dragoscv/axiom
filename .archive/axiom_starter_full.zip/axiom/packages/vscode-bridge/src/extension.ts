
export function activate() {
  // Skeleton: in a full implementation we'd autodiscover @axiom/mcp and register it
  console.log("[AXIOM] VS Code Bridge activated");
}
export function deactivate() {}
