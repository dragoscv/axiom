
# AXIOM MCP API (HTTP demo)

POST /parse      { source }            -> { ir?, diagnostics[] }
POST /validate   { ir }                -> { ok, diagnostics[] }
POST /generate   { ir, profile? }      -> { artifacts[], manifest }
POST /check      { manifest }          -> { passed, report[] }

No AI inside MCP. Agents translate NL → AXIOM source/IR, then call these endpoints.
