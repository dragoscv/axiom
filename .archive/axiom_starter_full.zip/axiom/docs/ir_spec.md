# AXIOM IR 1.0.0

Canonical JSON representation validated by Zod types.
See `@axiom/core/src/ir.ts` for the authoritative schema.
